package Utility;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import Base.DriverManager;

public class Scroll extends DriverManager {
	
	 
	
	public void scrollUntilElementVisible(WebElement element) throws InterruptedException  {	
	 
	((JavascriptExecutor) webDriver.get()).executeScript("arguments[0].scrollIntoView(true);", element);
	Thread.sleep(500); 
	}

}
