package Utility;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import io.qameta.allure.Allure;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import Base.DriverManager;



public class Util extends DriverManager {
	
	public enum TimeOut {

	    LOW(5),

	    MIDDLE(10),

	    HIGH(15),

	    CUSTOM_MAX(60);

	    private final int value;

	  public int getValue() {

	        return value;

	    }
	    // enum constructor - cannot be public or protected

	    private TimeOut(int value) {

	        this.value = value;

	    }
	}

	
	   public static void clickFunction(WebElement clickElement ,TimeOut timeOut){
		   try {
		   System.out.println("Start click element ! ********* ");
		   	WebDriverWait wait = new WebDriverWait(webDriver.get(), timeOut.value);
	        wait.until(ExpectedConditions.elementToBeClickable(clickElement));

	        clickElement.click();
	        System.out.println("Element is clicked succesfuly ! *********"+clickElement);
			   Allure.addAttachment("Click is Success","Succes"+clickElement);
		   } catch(Exception e) {
			   System.out.println("Element is not clicked  !!! ********* " +e);
			   Allure.addAttachment("Click is Failed","Failed");
		   }
	    }

	    public static void sendKeysFunction(WebElement sendKeysElement, String value, TimeOut timeOut){
	    	try {
	    	System.out.println("Start sendKeys Text ! ********* ");
	    	WebDriverWait wait = new WebDriverWait(webDriver.get(), timeOut.value);
	        wait.until(ExpectedConditions.visibilityOf(sendKeysElement));

	        sendKeysElement.sendKeys(value);
	        System.out.println("Text is sendKeys succesfuly ! ********* "+sendKeysElement);
				Allure.addAttachment("SendKeys is Success","Succes"+sendKeysElement);
	    	}catch(Exception e){
	    		System.out.println("Text is not sendKeys !!! ********* " +e);
				Allure.addAttachment("SendKeys is Failed","Failed");
	    	}
	    }

	    public static void selectFromDropDown(WebElement element , String text) {

			Util.sendKeysFunction(element, text, TimeOut.MIDDLE);
			Util.useKeyboardButton(element,"DOWN");
			Util.useKeyboardButton(element,"ENTER");
		}
		public static void useKeyboardButton(WebElement sendKeysElement, String keyType){
			try {
				System.out.println("Start Press Keyboard Button ! ********* ");

				switch (keyType) {

					case "ENTER":
						String enter = Keys.chord(Keys.ENTER);
						sendKeysElement.sendKeys(enter);
						break;

					case "DELETE":
						String delete = Keys.chord(Keys.DELETE);
						sendKeysElement.sendKeys(delete);
						break;

					case "UP":
						String up = Keys.chord(Keys.UP);
						sendKeysElement.sendKeys(up);
						break;

					case "DOWN":
						String down = Keys.chord(Keys.DOWN);
						sendKeysElement.sendKeys(down);
						break;

					case "LEFT":
						String left = Keys.chord(Keys.LEFT);
						sendKeysElement.sendKeys(left);
						break;

					case "RIGHT":
						String right = Keys.chord(Keys.RIGHT);
						sendKeysElement.sendKeys(right);
						break;

					case "ESCAPE":
						String escape = Keys.chord(Keys.ESCAPE);
						sendKeysElement.sendKeys(escape);
						break;

					case "BACKSPACE":
						String backspace = Keys.chord(Keys.BACK_SPACE);
						sendKeysElement.sendKeys(backspace);
						break;

					case "TAB":
						String tab = Keys.chord(Keys.TAB);
						sendKeysElement.sendKeys(tab);
						break;
				}
			}catch(Exception e){
				System.out.println("Text is not sendKeys !!! ********* " +e);
				Allure.addAttachment("SendKeys is Failed","Failed");
			}
		}

	static FileReader reader;
	static Properties p;

	public static byte[] takeScreenShot() {
		return ((TakesScreenshot) webDriver.get()).getScreenshotAs(OutputType.BYTES);
	}

	public static String properties(String fileName, String value) {
		String propValue = null;
		try {
			reader = new FileReader("AppConfig" + "//" + fileName + ".properties");
			p = new Properties();
			p.load(reader);
			propValue = p.getProperty(value);
		} catch (FileNotFoundException e) {
			new RuntimeException("File is not found : " + fileName);
		} catch (IOException e) {
			e.printStackTrace();
			new RuntimeException("IO exception occured");
		}
		return propValue;
	}
		

	public static String getURL() {
		return webDriver.get().getCurrentUrl();
	}
}
