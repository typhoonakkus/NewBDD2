package Utility;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Base.DriverManager;

public class MoveToElement extends DriverManager{
	
	public void moveToElement(WebElement element) {
		
		Actions actions = new Actions(webDriver.get());
		actions.moveToElement(element);
		actions.perform();
	}

}
